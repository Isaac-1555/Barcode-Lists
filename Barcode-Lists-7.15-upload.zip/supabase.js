const SUPABASE_URL = 'https://jahcgdgmdasrhzcuynkw.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImphaGNnZGdtZGFzcmh6Y3V5bmt3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ5NzI3NDcsImV4cCI6MjA5MDU0ODc0N30.GfErij5lvZIsvGhSq4WsIf-AEhugNXw02nzgQXx5xHw';

let supabaseClient = null;

function simpleHash(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return hash.toString(36);
}

async function hashPassword(password) {
  return simpleHash(password);
}

async function login(storeNumber, password) {
  const passwordHash = await hashPassword(password);

  const response = await fetch(`${SUPABASE_URL}/rest/v1/stores?store_number=eq.${encodeURIComponent(storeNumber)}&select=*&limit=1`, {
    headers: {
      'apikey': SUPABASE_ANON_KEY,
      'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json'
    }
  });

  const data = await response.json().catch(() => []);

  if (!response.ok) {
    console.error('Login error:', response.status, data);
    throw new Error(`Server error: ${response.status}`);
  }

  let storeId;

  if (data && data.length > 0) {
    if (data[0].password_hash !== passwordHash) {
      throw new Error('Invalid password');
    }
    storeId = data[0].id;
  } else {
    const createResponse = await fetch(`${SUPABASE_URL}/rest/v1/stores`, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation'
      },
      body: JSON.stringify({
        store_number: storeNumber,
        password_hash: passwordHash
      })
    });

    if (!createResponse.ok) {
      throw new Error('Failed to create account');
    }

    const newStore = await createResponse.json();
    storeId = newStore[0]?.id || newStore.id;
  }

  const session = {
    storeNumber,
    storeId,
    passwordHash
  };

  await chrome.storage.local.set({ supabaseSession: session });

  return session;
}

async function logout() {
  await chrome.storage.local.remove('supabaseSession');
}

async function getSession() {
  const result = await chrome.storage.local.get('supabaseSession');
  return result.supabaseSession || null;
}

async function isOnline() {
  try {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/stores?select=id&limit=1`, {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    });
    return response.ok;
  } catch {
    return false;
  }
}

async function syncImportantCategories(session) {
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/important_categories?store_id=eq.${session.storeId}&select=category_name`,
    {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );

  if (!response.ok) return {};

  const data = await response.json();
  const important = {};
  data.forEach(row => {
    important[row.category_name] = true;
  });
  return important;
}

async function markCategoryImportant(session, categoryName) {
  await fetch(
    `${SUPABASE_URL}/rest/v1/important_categories?on_conflict=store_id,category_name`,
    {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'resolution=merge-duplicates'
      },
      body: JSON.stringify({
        store_id: session.storeId,
        category_name: categoryName
      })
    }
  );
}

async function unmarkCategoryImportant(session, categoryName) {
  await fetch(
    `${SUPABASE_URL}/rest/v1/important_categories?store_id=eq.${session.storeId}&category_name=eq.${encodeURIComponent(categoryName)}`,
    {
      method: 'DELETE',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );
}

async function fetchCategoryOrder(session) {
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/category_order?store_id=eq.${session.storeId}&select=category_name,position&order=position.asc`,
    {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );

  if (!response.ok) return [];
  return await response.json();
}

async function syncCategoryOrder(session, categoryOrder) {
  await fetch(
    `${SUPABASE_URL}/rest/v1/category_order?store_id=eq.${session.storeId}`,
    {
      method: 'DELETE',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );

  if (categoryOrder.length === 0) return;

  const insertData = categoryOrder.map((name, index) => ({
    store_id: session.storeId,
    category_name: name,
    position: index
  }));

  await fetch(`${SUPABASE_URL}/rest/v1/category_order`, {
    method: 'POST',
    headers: {
      'apikey': SUPABASE_ANON_KEY,
      'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
      'Prefer': 'return=minimal'
    },
    body: JSON.stringify(insertData)
  });
}

async function deleteCategoryOrder(session, categoryName) {
  await fetch(
    `${SUPABASE_URL}/rest/v1/category_order?store_id=eq.${session.storeId}&category_name=eq.${encodeURIComponent(categoryName)}`,
    {
      method: 'DELETE',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );
}

async function fetchCopiedBarcodes(session) {
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/copied_barcodes?store_id=eq.${session.storeId}&select=barcode_value&copied=eq.true`,
    {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );

  if (!response.ok) return {};
  const data = await response.json();
  const copied = {};
  data.forEach(row => {
    copied[row.barcode_value] = true;
  });
  return copied;
}

async function copyBarcodeRemote(session, barcodeValue) {
  await fetch(
    `${SUPABASE_URL}/rest/v1/copied_barcodes?on_conflict=store_id,barcode_value`,
    {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'resolution=merge-duplicates'
      },
      body: JSON.stringify({
        store_id: session.storeId,
        barcode_value: barcodeValue,
        copied: true
      })
    }
  );
}

async function unmarkBarcodeCopied(session, barcodeValue) {
  await fetch(
    `${SUPABASE_URL}/rest/v1/copied_barcodes?store_id=eq.${session.storeId}&barcode_value=eq.${encodeURIComponent(barcodeValue)}`,
    {
      method: 'DELETE',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );
}

async function addBarcodeRemote(session, categoryName, barcodeValue) {
  const response = await fetch(`${SUPABASE_URL}/rest/v1/barcodes`, {
    method: 'POST',
    headers: {
      'apikey': SUPABASE_ANON_KEY,
      'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
      'Prefer': 'return=minimal'
    },
    body: JSON.stringify({
      store_id: session.storeId,
      category_name: categoryName,
      barcode_value: barcodeValue
    })
  });
  return response.ok;
}

async function removeBarcodeRemote(session, categoryName, barcodeValue) {
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/barcodes?store_id=eq.${session.storeId}&category_name=eq.${encodeURIComponent(categoryName)}&barcode_value=eq.${encodeURIComponent(barcodeValue)}`,
    {
      method: 'DELETE',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );
  return response.ok;
}

async function clearCategoryRemote(session, categoryName) {
  await fetch(
    `${SUPABASE_URL}/rest/v1/barcodes?store_id=eq.${session.storeId}&category_name=eq.${encodeURIComponent(categoryName)}`,
    {
      method: 'DELETE',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );
}


async function fetchComments(session) {
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/barcode_comments?store_id=eq.${session.storeId}&select=barcode_value,comment`,
    {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );

  if (!response.ok) return {};

  const data = await response.json();
  const comments = {};
  data.forEach(c => {
    if (c.comment) {
      comments[c.barcode_value] = c.comment;
    }
  });
  return comments;
}

async function renameCategoryRemote(session, oldName, newName) {
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/barcodes?store_id=eq.${session.storeId}&category_name=eq.${encodeURIComponent(oldName)}`,
    {
      method: 'PATCH',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=minimal'
      },
      body: JSON.stringify({
        category_name: newName
      })
    }
  );

  await fetch(
    `${SUPABASE_URL}/rest/v1/category_order?store_id=eq.${session.storeId}&category_name=eq.${encodeURIComponent(oldName)}`,
    {
      method: 'PATCH',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=minimal'
      },
      body: JSON.stringify({
        category_name: newName
      })
    }
  );

  const importantResp = await fetch(
    `${SUPABASE_URL}/rest/v1/important_categories?store_id=eq.${session.storeId}&category_name=eq.${encodeURIComponent(oldName)}&select=id`,
    {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );
  const importantData = await importantResp.json();
  if (importantData && importantData.length > 0) {
    await fetch(
      `${SUPABASE_URL}/rest/v1/important_categories?store_id=eq.${session.storeId}&category_name=eq.${encodeURIComponent(oldName)}`,
      {
        method: 'PATCH',
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify({
          category_name: newName
        })
      }
    );
  }

  return response.ok;
}

async function syncFromRemote(session) {
  const barcodesResponse = await fetch(
    `${SUPABASE_URL}/rest/v1/barcodes?store_id=eq.${session.storeId}&select=*&order=created_at`,
    {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );

  if (!barcodesResponse.ok) {
    throw new Error('Failed to fetch data');
  }

  const barcodes = await barcodesResponse.json();

  const categories = {};
  const categoryOrderFromData = [];

  barcodes.forEach(b => {
    if (!categories[b.category_name]) {
      categories[b.category_name] = [];
      categoryOrderFromData.push(b.category_name);
    }
    if (!categories[b.category_name].includes(b.barcode_value)) {
      categories[b.category_name].push(b.barcode_value);
    }
  });

  const comments = await fetchComments(session);
  const importantCategories = await syncImportantCategories(session);
  const copiedBarcodes = await fetchCopiedBarcodes(session);
  const categoryOrderRows = await fetchCategoryOrder(session);

  const categoryOrder = categoryOrderRows.length > 0
    ? categoryOrderRows.map(r => r.category_name)
    : categoryOrderFromData;

  const missingInOrder = categoryOrderFromData.filter(n => !categoryOrder.includes(n));
  missingInOrder.forEach(n => categoryOrder.push(n));

  const filteredOrder = categoryOrder.filter(n => categories[n]);

  return {
    categoryOrder: filteredOrder,
    categories,
    comments,
    importantCategories,
    insertedBarcodes: copiedBarcodes,
    active: filteredOrder[0] || null
  };
}

async function syncToRemote(session, state) {
  await fetch(
    `${SUPABASE_URL}/rest/v1/stores?id=eq.${session.storeId}`,
    {
      method: 'PATCH',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=minimal'
      },
      body: JSON.stringify({
        updated_at: new Date().toISOString()
      })
    }
  );

  await fetch(
    `${SUPABASE_URL}/rest/v1/barcodes?store_id=eq.${session.storeId}`,
    {
      method: 'DELETE',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );

  const insertData = [];
  state.categoryOrder.forEach(categoryName => {
    const barcodes = state.categories[categoryName] || [];
    barcodes.forEach(barcode => {
      insertData.push({
        store_id: session.storeId,
        category_name: categoryName,
        barcode_value: barcode
      });
    });
  });

  if (insertData.length > 0) {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/barcodes`, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=minimal'
      },
      body: JSON.stringify(insertData)
    });

    if (!response.ok) {
      throw new Error('Failed to save data');
    }
  }

  await syncCategoryOrder(session, state.categoryOrder);

  const currentImportant = Object.keys(state.importantCategories || {});
  const allImportantResp = await fetch(
    `${SUPABASE_URL}/rest/v1/important_categories?store_id=eq.${session.storeId}&select=category_name`,
    {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );
  if (allImportantResp.ok) {
    const allImportant = await allImportantResp.json();
    const existingImportantNames = allImportant.map(r => r.category_name);
    const toRemove = existingImportantNames.filter(n => !currentImportant.includes(n));
    const toAdd = currentImportant.filter(n => !existingImportantNames.includes(n));

    for (const name of toRemove) {
      await unmarkCategoryImportant(session, name);
    }
    for (const name of toAdd) {
      await markCategoryImportant(session, name);
    }
  }

  const copiedBarcodesResponse = await fetch(
    `${SUPABASE_URL}/rest/v1/copied_barcodes?store_id=eq.${session.storeId}&select=barcode_value`,
    {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );
  if (copiedBarcodesResponse.ok) {
    const allCopied = await copiedBarcodesResponse.json();
    const existingCopied = allCopied.map(r => r.barcode_value);
    const currentCopied = Object.keys(state.insertedBarcodes || {});
    const toUncopy = existingCopied.filter(v => !currentCopied.includes(v));
    const toCopy = currentCopied.filter(v => !existingCopied.includes(v));

    for (const value of toUncopy) {
      await unmarkBarcodeCopied(session, value);
    }
    for (const value of toCopy) {
      await copyBarcodeRemote(session, value);
    }
  }
}

async function getComment(storeId, barcodeValue) {
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/barcode_comments?store_id=eq.${storeId}&barcode_value=eq.${encodeURIComponent(barcodeValue)}&select=comment`,
    {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );

  const comments = await response.json();
  return comments && comments.length > 0 ? comments[0].comment : null;
}

async function saveComment(storeId, barcodeValue, comment) {
  const truncated = comment.slice(0, 250);

  await fetch(
    `${SUPABASE_URL}/rest/v1/barcode_comments?on_conflict=store_id,barcode_value`,
    {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'resolution=merge-duplicates'
      },
      body: JSON.stringify({
        store_id: storeId,
        barcode_value: barcodeValue,
        comment: truncated,
        updated_at: new Date().toISOString()
      })
    }
  );
}

async function deleteComment(storeId, barcodeValue) {
  await fetch(
    `${SUPABASE_URL}/rest/v1/barcode_comments?store_id=eq.${storeId}&barcode_value=eq.${encodeURIComponent(barcodeValue)}`,
    {
      method: 'DELETE',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );
}

async function markCategoryOpened(session, categoryName) {
  await fetch(
    `${SUPABASE_URL}/rest/v1/opened_categories?on_conflict=store_id,category_name`,
    {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'resolution=merge-duplicates'
      },
      body: JSON.stringify({
        store_id: session.storeId,
        category_name: categoryName,
        opened_at: new Date().toISOString()
      })
    }
  );
}

async function getBarcodeCount(storeId) {
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/barcodes?store_id=eq.${storeId}&select=id&limit=1`,
    {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Prefer': 'count=exact'
      }
    }
  );
  if (!response.ok) return 0;
  const totalStr = response.headers.get('content-range');
  if (totalStr) {
    const match = totalStr.match(/\/(\d+)$/);
    if (match) return parseInt(match[1], 10);
  }
  const data = await response.json();
  return data.length;
}

async function getLatestBarcodeTimestamp(storeId) {
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/barcodes?store_id=eq.${storeId}&select=created_at&order=created_at.desc&limit=1`,
    {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    }
  );
  if (!response.ok) return null;
  const data = await response.json();
  return data && data.length > 0 ? data[0].created_at : null;
}
